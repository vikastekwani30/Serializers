from django.shortcuts import render
from .serializers import UserSerializers
from .models import User
from django.http import JsonResponse


# Create your views here.

def user_list(request):
    user = User.objects.all()
    serializer = UserSerializers(user, many=True)
    return JsonResponse({'user': serializer.data}, safe=False)
