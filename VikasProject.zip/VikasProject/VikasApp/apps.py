from django.apps import AppConfig


class VikasappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "VikasApp"
